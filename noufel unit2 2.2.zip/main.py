class player():

  def play(self):
    print("the player is playing cricket")

class Batsman(player):
  
  def play(self):
    print("the batsman is batting")
    
class Bowler(player):

  def play(self):
    print("the bowler is bowling")

obj1 = Batsman()
obj2 = Bowler()

obj1.play()
obj2.play()